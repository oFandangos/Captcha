<?php
    session_start(); 
    include_once 'conexao.php';
    
    $email1 = $_SESSION['email'];
    
    print_r($email1);
    
    $sql = "SELECT * FROM user where email = '$email1'";
    $result = mysqli_query($conexao, $sql);
    
    $linha = mysqli_fetch_assoc($result);
    $email = $linha['email'];

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>CAPTCHA</title>
    </head>
    <body>
        <h1>CAPTCHA</h1>
        <div class="divisao">
            <p>Bem vindo, <?php echo $email; ?>!<br>
            Você está logado ao sistema.
            </p>
        <br><br>
    </div>
        <a href="index.php"><button class="btn" id="botao">SAIR</button></a>
</body>
</html>
<?php
?>