<?php
$host = "localhost";
$user = "root";
$pass = "aluno"; //deixar vazio
$banco = "captcha";
$conexao = new mysqli($host, $user, $pass, $banco);

if($conexao->connect_error){
    die("Conexão falhou: " . $conexao->connect_error);
}

?>