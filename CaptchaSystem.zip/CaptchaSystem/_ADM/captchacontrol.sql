--talvez precise mudar o nome da database

CREATE DATABASE captcha;
USE captcha;

CREATE TABLE captchacontrol (
  id int(4) AUTO_INCREMENT PRIMARY KEY,
  imagem varchar(12) NOT NULL,
  string varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE user (
  id_user int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email varchar(30) not null,
  senha varchar(60) not null
);

INSERT INTO USER (email, senha) VALUES ('celso@gmail.com','senhafraca');
