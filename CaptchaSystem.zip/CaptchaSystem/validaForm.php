<?php

    session_start();

    include_once 'conexao.php';

    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $numero = $_POST['num'];
    
    $sqlcaptcha = "SELECT IMAGEM, STRING FROM CAPTCHACONTROL WHERE ID = '$numero' ORDER BY ID ASC";
    $resultado = mysqli_query($conexao, $sqlcaptcha);
    $linha = mysqli_fetch_assoc($resultado);
    
    $captcha = $_POST['string']; //pegando do index
    $string = $linha['STRING']; //pegando do banco de dados
    
    if(empty ($email and $senha and $captcha)){
        echo '<h4>insira todas os campos</h4>';
        include_once 'index.php';
        //pegar o nome do banco de dados e verificar por condicional se o nome do catpcha inserido é o mesmo que está no banco
    }elseif($captcha == $string){
        
        $sql = "SELECT email, senha FROM user WHERE email = '$email' and senha = '$senha'";
        
        $result = mysqli_query($conexao, $sql);
        
        $row = mysqli_num_rows($result);
        
        if($row == 1){
            $resultado = mysqli_fetch_assoc($result);
            $_SESSION['email'] = $email;
            $_SESSION['senha'] = $senha;
            header('location: logado.php');
        }else{
            echo '<h4>Usuário inexistente</h4>';
            include_once 'index.php';
        }
    }else{
        echo '<h4>Captcha incorreto</h4>';
        include_once 'index.php';
    }


?>