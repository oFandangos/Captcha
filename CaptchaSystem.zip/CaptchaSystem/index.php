<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php 
$img = 'imgcaptcha/'; 

include_once 'conexao.php';

$first = "SELECT id FROM CAPTCHACONTROL ORDER BY ID ASC"; //pegando o primeiro valor do array
$resultado = mysqli_query($conexao, $first);

$last = "SELECT id FROM CAPTCHACONTROL ORDER BY ID DESC"; //pegando o último valor do array
$resultado2 = mysqli_query($conexao, $last);

//pegando o primeiro e o último valor do banco de dados para fazer a função rand() escolher o id da imagem aleatóriamente.
$linha = mysqli_fetch_assoc($resultado);
$linha2 = mysqli_fetch_assoc($resultado2);
$id = $linha['id'];
$id2 = $linha2['id'];
$num = rand($id, $id2);

$sqlimg = "SELECT * FROM captchacontrol WHERE id = '$num'";
$conn = new mysqli($host, $user, $pass, $banco);
$resultado = mysqli_query($conn, $sqlimg);

$linha = mysqli_fetch_assoc($resultado);
$imagem = $linha['imagem'];
$captcha = $linha['string'];

?>

    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <form action="validaForm.php" method="POST" name="form">
                    <h1>Área de login</h1>
                    <input type="hidden" name="num" value="<?php echo $num; ?> ">
                    <div class="form-group">
                    <input type="email" class="inputs" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email" name="email">
                    </div>
                    <div class="form-group">
                    <input type="password" class="inputs" id="exampleInputPassword1" placeholder="Senha" name="senha">
                    </div>
                    <div class="form-group">
                    <img src="<?php echo $img.$imagem; ?>" class="captchaImagem">
                    <input type="text" class="inputs" id="captcha" placeholder="Insira o texto da imagem acima" name="string"> <!-- dentro da tag php colocar o id da imagem -->
                    </div>
                    <button type="submit" class="btn">Enviar</button>
                    <br><br>
                </form>
                <a href="captchaCreator/captchaCreator.php"><button class="btn">Para criar imagens para o captcha clique aqui </button></a>
            </div>
        </div>
    </div>

    
</body>
</html>