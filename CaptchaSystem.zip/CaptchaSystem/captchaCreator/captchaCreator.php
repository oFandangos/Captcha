<?php
session_start();
include_once '../conexao.php';
    header("content-type: image/gif");

    //gerando o texto aleatório do captcha
    function geraString($n){
        $caracteres = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $randomstring = "";
        for($i = 0; $i <= $n; $i++){
            $index = rand(0, strlen($caracteres) -1); //o -1 serve para nao pegar o espaço do ultimo caractere.
            $randomstring .= $caracteres[$index];
        }
        return $randomstring;
    }

    // echo geraString(25);


    //criando a imagem, largura e altura, cor do fundo e do texto
    for($i = 1; $i <= 5; $i++){
        $imagem = ImageCreate(100, 38);
        $bgcolor = ImageColorAllocate($imagem, 90, 30, 120);
        $txtColor = ImageColorAllocate($imagem, 255, 255, 255);
        $stringTt = geraString(5); //texto da imagem
        $stringNome = geraString(5); //titulo da imagem
        $imgNome = $stringNome . ".gif";
        imagestring($imagem, 5, 20, 10, $stringTt, $txtColor);
        imagegif($imagem, "../imgcaptcha/" . $imgNome);
        imagedestroy($imagem); //cria a imagem e a destrói em seguida, para não ficar armazenado na memória

        $_SESSION['captcha'] = $imgNome;

        $query = "insert into captchacontrol (imagem, string) values ('{$imgNome}', '{$stringTt}');";
        $conexao->query($query);
    }
    
    $conexao->close();

?>